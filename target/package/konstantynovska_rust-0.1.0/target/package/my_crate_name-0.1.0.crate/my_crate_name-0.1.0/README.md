# my_crate_name

Мій crate

## Запуск
```bash
cargo run